#!/bin/bash

array=( 1ag2 1bpi 1ftg 1lz1 1rn1 1vqb 2rn2 1arr 1bta 1g6n 1mbg 1rop 1w4h 2zta 1aye 1bvc 1hfy 1otr 1rtb 1wq5 3hhr 1ayf 1c2r 1hfz 1pga 1rx4 1ycc 3mbp 1b26 1c9o 1iob 1pin 1stn 2abd 3ssi 1b5m 1csp 1l63 1poh 1sup 2ci2 451c 1bni 1flv 1lrp 1rgg 1tpk 2lzm 4lyz )

numArgs=$#
pdbID=""

if [ $numArgs -gt "2" ]; then
    echo " Received more than 1 argument"
    echo " Expecting 1 or 0 or 2 "
    echo " quitting"
    exit
elif [ $numArgs == "1" ]; then
    pdbID=${1}
    echo " Received single argument $pdbID"
    echo " Making config file"
    configCommand="/usr/bin/python3.4 makeRigidityAnalysisXMLs.py ${pdbID}"
    `${configCommand}`
    echo " Performing Rigidity Analysis on ${pdbID}"
    curateCommand="../bin/kinariMolWithBondInputExe ${pdbID}RigidityAnalysis.xml"
    `${curateCommand}`
elif [ $numArgs == "2" ]; then
    pdbID=${1}
    chainID=${2}
    echo " Received two arguments $pdbID and $chainID"
    echo " Making config file"
    configCommand="/usr/bin/python3.4 makeRigidityAnalysisXMLs.py ${pdbID} ${chainID}"
    `${configCommand}`
    echo " Performing Rigidity Analysis on ${pdbID} chain ${chainID}"
    curateCommand="../bin/kinariMolWithBondInputExe ${pdbID}.${chainID}.RigidityAnalysis.xml"
    `${curateCommand}`
elif [ $numArgs == "0" ]; then
    echo " Received no arguments "
    for pdbID in "${array[@]}" 
    do
	configCommand="/usr/bin/python3.4 makeRigidityAnalysisXMLs.py ${pdbID}"
	`${configCommand}`
	echo " Performing Rigidity Analysis on ${pdbID}"
	curateCommand="../bin/kinariMolWithBondInputExe ${pdbID}RigidityAnalysis.xml"
	`${curateCommand}`
    done
fi


