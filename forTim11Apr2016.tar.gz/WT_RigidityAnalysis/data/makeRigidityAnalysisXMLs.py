# import system calls
import sys

# get PDBID and chainID
pdbID = sys.argv[1]
chainID = sys.argv[2]

# generate output name
fileOutName = pdbID + "." + chainID + ".RigidityAnalysis.xml"

# file input and output
fileIn = open("rigidityAnalysisTemplate.txt", "r")
fileOut = open(fileOutName, "w")

# prase input file, pipe to output
for line in fileIn :
    if "{PDBID}" in line :
        newLine = line.replace("{PDBID}", pdbID)
        if "{CHAINID}" in newLine :
            fileOut.write(newLine.replace("{CHAINID}", chainID))
        else:
            fileOut.write(newLine)
    elif "{CHAINID}" in line:
        fileOut.write(line.replace("{CHAINID}", chainID))
    else:
        fileOut.write(line)

# close input and output files
fileIn.close()
fileOut.close()
